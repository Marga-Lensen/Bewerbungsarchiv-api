# 📁 Beispielunterlagen zur Bewerbung

In diesem Ordner findest du Textvorlagen und Links zur Unterstützung bei der Erstellung deiner Bewerbungsunterlagen:

- Ein Beispiel-Anschreiben im Markdown-Format (`anschreiben-beispiel-text.md`)
- Gestaltete Anschreiben und Lebensläufe im PDF-Format
- Eine Link-Sammlung zu Vorlagen-Tools (`vorlagen-tips-n-links.md`)

💡 Die Dateien dienen zur Inspiration – deine eigenen Unterlagen solltest du individuell gestalten und dann über die Web App "`BewerbungsArchiv`" (folgt demnächst) hochladen.
